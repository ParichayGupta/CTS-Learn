package com.cognizant.bakingo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BakingoCakeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
